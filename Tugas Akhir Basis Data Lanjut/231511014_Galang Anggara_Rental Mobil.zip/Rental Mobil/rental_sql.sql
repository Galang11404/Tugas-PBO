-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Feb 2025 pada 13.13
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kendaraan`
--

CREATE TABLE `kendaraan` (
  `id_kendaraan` int(11) NOT NULL,
  `nomor_polisi` varchar(15) NOT NULL,
  `merk` varchar(50) NOT NULL,
  `tipe` varchar(50) DEFAULT NULL,
  `warna` varchar(30) DEFAULT NULL,
  `tahun_pembuatan` year(4) DEFAULT NULL,
  `harga_sewa_per_hari` decimal(10,2) NOT NULL,
  `status_kendaraan` enum('Tersedia','Disewa') DEFAULT 'Tersedia',
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kendaraan`
--

INSERT INTO `kendaraan` (`id_kendaraan`, `nomor_polisi`, `merk`, `tipe`, `warna`, `tahun_pembuatan`, `harga_sewa_per_hari`, `status_kendaraan`, `foto`) VALUES
(1, 'B1234XYZ', 'Toyota', 'Avanza', 'Hitam', '2020', 300000.00, 'Tersedia', '679f2d71d7611_download.jpeg'),
(2, 'B5678ABC', 'Honda', 'Brio', 'Kuning', '2019', 250000.00, 'Tersedia', '679f2d7b796e2_brio.jpeg'),
(3, 'B9012DEF', 'Mitsubishi', 'Pajero', 'Silver', '2021', 500000.00, 'Disewa', '679f2d85b4cc9_pajero.jpeg'),
(5, 'B9012WAF', 'Honda', 'Civic', 'Putih', '2018', 650000.00, 'Disewa', '679f2db5607ab_civic.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` text DEFAULT NULL,
  `nomor_telepon` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `alamat`, `nomor_telepon`, `email`) VALUES
(1, 'Andi Setiawan', 'Jl. Sudirman No. 45, Jakarta', '081234567890', 'andi.setiawan@gmail.com'),
(2, 'Budi Santoso', 'Jl. Thamrin No. 22, Bandung', '082345678901', 'budi.santoso@yahoo.com'),
(3, 'Citra Dewi', 'Jl. Malioboro No. 12, Yogyakarta', '083456789012', 'citra.dewi@hotmail.com'),
(5, 'Roy kiyosi', 'Klaten', '087654321140', 'roy@umc.ac.id'),
(6, 'Danu yanuar dinata', 'Tuparev', '087654321123', 'danu@umc.ac.id');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `tanggal_bayar` date NOT NULL,
  `jumlah_bayar` decimal(10,2) NOT NULL,
  `metode_pembayaran` enum('Cash','Transfer','Kartu Kredit') DEFAULT 'Cash'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_transaksi`, `tanggal_bayar`, `jumlah_bayar`, `metode_pembayaran`) VALUES
(1, 1, '2024-12-22', 600000.00, 'Cash'),
(2, 3, '2024-06-11', 3500000.00, 'Transfer'),
(4, 2, '2024-12-13', 500000.00, 'Transfer');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksirental`
--

CREATE TABLE `transaksirental` (
  `id_transaksi` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_kendaraan` int(11) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `total_harga` decimal(10,2) DEFAULT NULL,
  `status_rental` enum('Berlangsung','Selesai') DEFAULT 'Berlangsung'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksirental`
--

INSERT INTO `transaksirental` (`id_transaksi`, `id_pelanggan`, `id_kendaraan`, `tanggal_mulai`, `tanggal_selesai`, `total_harga`, `status_rental`) VALUES
(1, 1, 1, '2024-12-20', '2024-12-22', 600000.00, 'Selesai'),
(2, 2, 2, '2024-12-21', '2024-12-23', 500000.00, 'Berlangsung'),
(3, 3, 3, '2024-06-03', '2024-06-10', 3500000.00, 'Selesai'),
(5, 5, 5, '2025-02-19', '2025-02-21', 1500000.00, 'Berlangsung');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kendaraan`
--
ALTER TABLE `kendaraan`
  ADD PRIMARY KEY (`id_kendaraan`),
  ADD UNIQUE KEY `nomor_polisi` (`nomor_polisi`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`),
  ADD UNIQUE KEY `nomor_telepon` (`nomor_telepon`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indeks untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `fk_transaksi` (`id_transaksi`);

--
-- Indeks untuk tabel `transaksirental`
--
ALTER TABLE `transaksirental`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_pelanggan` (`id_pelanggan`),
  ADD KEY `id_kendaraan` (`id_kendaraan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kendaraan`
--
ALTER TABLE `kendaraan`
  MODIFY `id_kendaraan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `transaksirental`
--
ALTER TABLE `transaksirental`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `fk_transaksi` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksirental` (`id_transaksi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transaksirental`
--
ALTER TABLE `transaksirental`
  ADD CONSTRAINT `transaksirental_ibfk_1` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`),
  ADD CONSTRAINT `transaksirental_ibfk_2` FOREIGN KEY (`id_kendaraan`) REFERENCES `kendaraan` (`id_kendaraan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
