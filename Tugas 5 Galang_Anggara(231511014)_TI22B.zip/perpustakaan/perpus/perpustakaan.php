<?php

include("../controllers/Buku.php");
include("../controllers/Anggota.php");
include("../controllers/Peminjaman.php");
include("../lib/functions.php");

$bukuObj = new BukuController();
$bukuRows = $bukuObj->getBukuList();

$anggotaObj = new AnggotaController();
$anggotaRows = $anggotaObj->getAnggotaList();

$peminjamanObj = new PeminjamanController();
$peminjamanRows = $peminjamanObj->getPeminjamanList();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table-section { display: none; }
        .active { display: block; }
        .table th {
        background-color: #2f4f42 !important; 
        color: white;
        }
        body {
            background-color: #e0ffff; /* Warna cyan */
        }
    </style>
</head>
<body class="py-5">
    
    <div class="container">
        <div class="d-flex mb-4">
            <button onclick="showTable('buku')" class="btn btn-primary me-2">Buku</button>
            <button onclick="showTable('anggota')" class="btn btn-primary me-2">Anggota</button>
            <button onclick="showTable('peminjaman')" class="btn btn-primary">Peminjaman</button>
        </div>
        <button class="bg-primary text-white px-4 py-2 rounded mb-4 flex items-center">
            <i class="fas fa-plus mr-2"></i> Create New Data
        </button>

        <!-- Table Buku -->
        <div id="buku" class="table-section card bg-secondary p-4 shadow-sm">
            <h2 class="mb-3 text-light text-center">Buku</h2>
            <div class="table-responsive">
                <table class="table table-bordered table-striped shadow">
                    <thead class="table-primary">
                        <tr>
                            <th>ID Buku</th>
                            <th>Judul</th>
                            <th>Penulis</th>
                            <th>Penerbit</th>
                            <th>Tahun Terbit</th>
                            <th>Jumlah</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($bukuRows as $row){ ?>
                        <tr>
                            <td><?php echo $row['id_buku']; ?></td>
                            <td><?php echo $row['judul']; ?></td>
                            <td><?php echo $row['penulis']; ?></td>
                            <td><?php echo $row['penerbit']; ?></td>
                            <td><?php echo $row['tahun_terbit']; ?></td>
                            <td><?php echo $row['jumlah']; ?></td>
                            <td>
                                <button class="btn btn-outline-primary btn-sm me-2"><i class="fas fa-pen"></i></button>
                                <button class="btn btn-outline-danger btn-sm"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Table Anggota -->
        <div id="anggota" class="table-section card p-4 shadow-sm bg-danger">
            <h2 class="mb-3 text-light text-center">Anggota</h2>
            <div class="table-responsive">
                <table class="table table-bordered table-striped shadow">
                    <thead class="table-primary">
                        <tr>
                            <th>ID Anggota</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Telepon</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($anggotaRows as $row){ ?>
                        <tr>
                            <td><?php echo $row['id_anggota']; ?></td>
                            <td><?php echo $row['nama']; ?></td>
                            <td><?php echo $row['alamat']; ?></td>
                            <td><?php echo $row['telepon']; ?></td>
                            <td>
                                <button class="btn btn-outline-primary btn-sm me-2"><i class="fas fa-pen"></i></button>
                                <button class="btn btn-outline-danger btn-sm"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Table Peminjaman -->
        <div id="peminjaman" class="table-section card p-4 shadow-sm bg-success">
            <h2 class="mb-3 text-light text-center">Peminjaman</h2>
            <div class="table-responsive">
                <table class="table table-bordered table-striped shadow">
                    <thead class="table-primary">
                        <tr>
                            <th>ID Peminjaman</th>
                            <th>ID Buku</th>
                            <th>ID Anggota</th>
                            <th>Tanggal Pinjam</th>
                            <th>Tanggal Kembali</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($peminjamanRows as $row){ ?>
                        <tr>
                            <td><?php echo $row['id_peminjaman']; ?></td>
                            <td><?php echo $row['id_buku']; ?></td>
                            <td><?php echo $row['id_anggota']; ?></td>
                            <td><?php echo $row['tanggal_pinjam']; ?></td>
                            <td><?php echo $row['tanggal_kembali']; ?></td>
                            <td>
                                <button class="btn btn-outline-primary btn-sm me-2"><i class="fas fa-pen"></i></button>
                                <button class="btn btn-outline-danger btn-sm"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function showTable(tableId) {
            document.querySelectorAll('.table-section').forEach(section => section.classList.remove('active'));
            document.getElementById(tableId).classList.add('active');
        }
        showTable('buku');  
    </script>

    <!-- Bootstrap and Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
