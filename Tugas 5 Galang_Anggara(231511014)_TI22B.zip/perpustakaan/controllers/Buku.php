<?php
include_once('../models/BukuModel.php');

class BukuController
{
    private $model;
    public function __construct()
    {
        $this->model = new BukuModel();
    } 

    public function getBukuList()
    {
        return $this->model->getBukuList();
    }
}
?>