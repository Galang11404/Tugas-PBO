<?php
include_once('../models/AnggotaModel.php');

class AnggotaController
{
    private $model;
    public function __construct()
    {
        $this->model = new AnggotaModel();
    } 

    public function getAnggotaList()
    {
        return $this->model->getAnggotaList();
    }
}
?>