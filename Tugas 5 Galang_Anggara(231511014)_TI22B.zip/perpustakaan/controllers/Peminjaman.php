<?php
include_once('../models/PeminjamanModel.php');

class PeminjamanController
{
    private $model;
    public function __construct()
    {
        $this->model = new PeminjamanModel();
    } 

    public function getPeminjamanList()
    {
        return $this->model->getPeminjamanList();
    }
}
?>