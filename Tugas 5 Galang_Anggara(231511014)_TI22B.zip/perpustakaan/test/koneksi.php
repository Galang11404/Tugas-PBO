<?php
include_once('../db/database.php');
$db = new Database();

?>