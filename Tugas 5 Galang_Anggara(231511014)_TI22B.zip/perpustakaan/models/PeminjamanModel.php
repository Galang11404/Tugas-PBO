<?php

include_once('../db/database.php');

class PeminjamanModel
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function getPeminjamanList()
    {
        $sql = 'SELECT * FROM peminjaman';
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }
}