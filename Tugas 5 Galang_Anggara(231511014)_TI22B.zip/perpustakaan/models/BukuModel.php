<?php

include_once('../db/database.php');

class BukuModel
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function getBukuList()
    {
        $sql = 'SELECT * FROM buku';
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }
}
